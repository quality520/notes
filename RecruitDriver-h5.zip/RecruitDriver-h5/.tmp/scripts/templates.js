this["JST"] = this["JST"] || {};

this["JST"]["exam"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (count, finalOne, num, question, title, undefined) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"questionWrap\"><div class=\"total\"><div class=\"inner\">" + (jade.escape((jade_interp = num) == null ? '' : jade_interp)) + "/" + (jade.escape((jade_interp = count) == null ? '' : jade_interp)) + "</div></div><div class=\"question\">" + (jade.escape((jade_interp = question.question) == null ? '' : jade_interp)) + "：</div><form class=\"options\">");
// iterate question.answer
;(function(){
  var $$obj = question.answer;
  if ('number' == typeof $$obj.length) {

    for (var $index = 0, $$l = $$obj.length; $index < $$l; $index++) {
      var answer = $$obj[$index];

buf.push("<label class=\"option\"><input type=\"radio\" name=\"q1\"" + (jade.attr("value", '' + (answer.index) + '', true, false)) + "/>" + (jade.escape((jade_interp = answer.item) == null ? '' : jade_interp)) + "</label>");
    }

  } else {
    var $$l = 0;
    for (var $index in $$obj) {
      $$l++;      var answer = $$obj[$index];

buf.push("<label class=\"option\"><input type=\"radio\" name=\"q1\"" + (jade.attr("value", '' + (answer.index) + '', true, false)) + "/>" + (jade.escape((jade_interp = answer.item) == null ? '' : jade_interp)) + "</label>");
    }

  }
}).call(this);

buf.push("</form></div><div class=\"wrap1\">");
if ( finalOne)
{
buf.push("<a id=\"submit\" am-btn=\"bigger block full\"" + (jade.attr("href", '#exam/' + (num+1) + '', true, false)) + " style=\"display:none\">交卷</a>");
}
else
{
buf.push("<a id=\"nextQ\" am-btn=\"bigger block full\"" + (jade.attr("href", '#exam/' + (num+1) + '', true, false)) + " style=\"display:none\">下一题</a>");
}
buf.push("</div>");}.call(this,"count" in locals_for_with?locals_for_with.count:typeof count!=="undefined"?count:undefined,"finalOne" in locals_for_with?locals_for_with.finalOne:typeof finalOne!=="undefined"?finalOne:undefined,"num" in locals_for_with?locals_for_with.num:typeof num!=="undefined"?num:undefined,"question" in locals_for_with?locals_for_with.question:typeof question!=="undefined"?question:undefined,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined,"undefined" in locals_for_with?locals_for_with.undefined:typeof undefined!=="undefined"?undefined:undefined));;return buf.join("");
};

this["JST"]["examEntrance"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (isExarm, title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"exam\"><div class=\"tit\">考试须知</div><p am-list=\"am-list\">考试之前请认真阅读培训资料。</p></div><div style=\"margin-top:80px\" class=\"wrap1\">");
if ( isExarm)
{
buf.push("<a am-btn=\"bigger block full\" href=\"#progress\">查看进度</a>");
}
else
{
buf.push("<a am-btn=\"bigger block full\" href=\"#exam/1\">开始考试</a>");
}
buf.push("</div>");}.call(this,"isExarm" in locals_for_with?locals_for_with.isExarm:typeof isExarm!=="undefined"?isExarm:undefined,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["home"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;

buf.push("<img src=\"images/index-banner.jpg\" class=\"fullwidth\"/><div class=\"index-btns\"><div am-row=\"am-row\"><div am-col=\"am-col\"><a am-btn=\"full bigger\" href=\"#reg\">在线报名</a></div></div><div am-row=\"am-row\"><div am-col=\"1/2\"><a am-btn=\"full bigger info\" href=\"#train\">在线培训</a></div><div am-col=\"1/2\"><a am-btn=\"full bigger info\" href=\"#examEntrance\">在线考试</a></div></div></div>");;return buf.join("");
};

this["JST"]["layout-default"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["login"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"login\"><div id=\"ID_err\" class=\"error\"></div><input id=\"ID\" am-input=\"big\" type=\"number\" placeholder=\"请输入身份证号码\"/><a am-btn=\"bigger full\" class=\"btn-login\">登录</a><div class=\"info\">用户通过身份证号登录后即可看到报名进度</div></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["notice"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"notice\"><div class=\"tit\">欢迎您访问爱代驾！<br>请您仔细阅读以下声明：</div><p am-list=\"am-list\">1.本条款适用于上海币达信息技术有限公司为客户提供的司机服务项目即：爱代驾。</p><p am-list=\"am-list\">2.客户签字即确认接受代驾服务的收费标准及爱代驾会员相关的最新政策，并依据收费标准和会员政策向爱代驾支付服务费用。</p><p am-list=\"am-list\">3.客户须根据爱代驾提供的驾驶员信息核实驾驶员工作证件及身份，如因未经身份核实而接受了非爱代驾派出的驾驶员提供的服务，所引发的纠纷或损害，爱代驾不承担任何责任。</p><p am-list=\"am-list\">4.客户在本协议签字即确认本次服务所用车辆具备爱代驾提供服务的三个必要条件：车辆手续齐全、车况正常、有车辆保险（须包含交强险、车辆损失险、\n第三者责任险）；如以上条件不具备，请客户如实告知爱代驾的驾驶员，由驾驶员向上海币达信息技术有限公司确认后告知客户是否可以提供本次服务。如因客户隐\n瞒以上状况带来的纠纷或者损害，爱代驾不承担任何责任，客户自行负责。</p></div><div class=\"wrap1\"><a am-btn=\"bigger block full\" href=\"#reg\">立即报名</a></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["pass"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><img src=\"images/pass.png\" class=\"examed-img\"/><div class=\"examed-info\">恭喜您通过考核</div><div class=\"wrap1\"><a am-btn=\"bigger block full\" href=\"#home\">去主页</a></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["progress"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"progress\"><div class=\"info\">用户：<span id='uid'>310115********2734</span></div><div class=\"lists\"><div class=\"list\">提交基础信息<a disabled=\"disabled\">已完成</a></div><div class=\"list\">在线培训<a id=\"isOnlineTrain\" href=\"#train\">去培训</a></div><div class=\"list\">在线考试<a id=\"isExarm\" href=\"#exam\">去考试</a></div></div><div class=\"signup-success\"><img src=\"images/envelope.png\"/><div class=\"msg\"><div class=\"tit\">恭喜您已完成报名</div></div></div></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["reg"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><div class=\"reg\"><div class=\"info\"><div class=\"tit\">录入信息</div><div class=\"txt\">*注意：您的驾龄满五年才能报名</div></div><div id=\"fristGainCardTime_err\" class=\"error\"></div><div class=\"block dropdown\"><input id=\"fristGainCardTime\" am-input=\"big\" format=\"yyyy-MM-dd\" placeholder=\"请输入初次领证时间\"/><!--span.placeholder 请输入初次领证时间--></div><div id=\"driverName_err\" class=\"error\"></div><div class=\"block\"><input id=\"driverName\" am-input=\"big\" placeholder=\"请输入姓名\"/></div><div id=\"phone_err\" class=\"error\"></div><div am-row=\"am-row\" class=\"block\"><div am-col=\"am-col\" style=\"width:60%\"><input id=\"phone\" am-input=\"big\" type=\"tel\" placeholder=\"请输入手机号码\"/></div><div am-col=\"am-col\" style=\"width:40%;padding-left:8px\"><button id=\"getverification\" am-btn=\"big full\">获取验证码</button></div></div><div id=\"verifyCode_err\" class=\"error\"></div><div class=\"block\"><input id=\"verifyCode\" am-input=\"big\" type=\"number\" placeholder=\"请输入验证码\"/></div><div id=\"provinceId_err\" class=\"error\"></div><div class=\"block dropdown\"><select id=\"provinceId\" am-input=\"big\"><option>请选择工作省</option></select></div><div id=\"cityId_err\" class=\"error\"></div><div class=\"block dropdown\"><select id=\"cityId\" am-input=\"big\"><option>请选择工作市</option></select></div><div id=\"districtId_err\" class=\"error\"></div><div class=\"block dropdown\"><select id=\"districtId\" am-input=\"big\"><option>请选择工作区/县</option></select></div><div id=\"sourceType_err\" class=\"error\"></div><div class=\"block dropdown\"><select id=\"sourceType\" am-input=\"big\"><option>请选择渠道来源</option></select></div><div id=\"nric_err\" class=\"error\"></div><div class=\"block\"><input id=\"nric\" am-input=\"big\" placeholder=\"请输入身份证号码\"/></div><div id=\"licenseType_err\" class=\"error\"></div><div class=\"block dropdown\"><select id=\"licenseType\" am-input=\"big\"><option>请选择驾照类型</option></select></div><button am-btn=\"bigger full\" class=\"submit\">提交</button></div><div class=\"reg-success\"><div class=\"inner\"><div class=\"msg\">恭喜您，信息已成功提交，<br>可继续参加培训。</div><div class=\"steps\"><div class=\"step\">信息提交</div><img src=\"images/step-arrow.png\"/><div class=\"step\">参加培训</div><img src=\"images/step-arrow.png\"/><div class=\"step\">参加考试</div></div><div class=\"bottom\"><a am-btn=\"bigger full\" href=\"#train\">参加培训</a></div></div></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["train"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (location, title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><style>/*price*/\n.price-main{\n    margin:0 10px;\n}\n.price-main>.ptit{\n    margin-top: 25px;\n    color: #222;\n}\n.price-main>table{\n    border:solid 1px #e1e1e1;\n    border-radius:5px;\n    font-size: 14px;\n    text-align: center;\n    width: 100%;\n    line-height: 38px;\n    margin-top: 8px;\n}\n.price-main>table tr>td{\n    border-top: dashed 1px #e1e1e1;\n}\n.price-main>table tr>td:nth-child(even){\n    color:#f60;\n    font-weight: bold;\n}\n.price-main>table tr>td:first-child{\n    width:40%;\n}\n.price-main>table tr:first-child>td{\n    font-weight: bold;\n    color:#000 !important;\n}\n.price-main>table tr:first-child>td{\n    border-top: none;\n}\n.price-main>.price-panel{\n    border:solid 1px #e1e1e1;\n    border-radius:5px;\n    font-size: 14px;\n    text-align: center;\n    line-height: 75px;\n    margin-top: 8px;\n    color:#000;\n}\n.price-main>.price-panel>.price{\n    font-size: 26px;\n    color:#f60;\n}\n.price-explain{\n    margin-bottom: 24px;\n    margin-top: 10px;\n    font-size: 14px;\n}\n.price-explain>.ptit{\n    line-height: 38px;\n}\n.price-explain>.ptxt{\n    line-height: 24px;\n    padding-left:15px;\n    text-indent: -12px;\n}\n.price-explain>.ptxt>span{\n    color:#20b818;\n}</style><ul am-accordion=\"am-accordion\"><li><a am-handle=\"am-handle\">企业文化</a><div am-content=\"am-content\"><p class=\"tit\">以爱的名义，服务创新，报效社会</p><p class=\"txt\">“爱代驾”隶属于上海币达信息技术有限公司（以下简称\"爱代驾\"），创建于2012年10月，是国内首家专业从事汽车驾驶服务的企业，公司以\"爱代驾\"为品牌推出各类代驾服务，包括酒后代驾、商务代驾、婚庆代驾、旅游代驾以及其它个性化服务。</p><p class=\"txt\">爱代驾是一家飞速发展的创业型公司，立足于互联网技术和智能手机LBS技术，最大限度压缩费用和时间的代驾服务突破了传统代驾模式的束缚，让创新成为传统行业发展新的动力。目前整个公司已经发展到200余人，团队内结构清晰、分工明确，团队成员平均年龄在25岁，年轻有活力，拥有蓬勃的朝气和无限的激情。</p></div></li><li><a am-handle=\"am-handle\">入职须知</a><div am-content=\"am-content\"><p am-list=\"am-list\">1.合作条件：五年驾龄、身份证、驾驶证、紧急联系人联系方式。非当地户籍的司机师傅需垫付500-2000元的安全押金，离职时全部退还。</p><p am-list=\"am-list\">2.爱代驾合作模式：爱代驾跟每一位代驾员是合作关系，每位合作代驾员需要准备一部GPS定位手机。当有时间想做代驾的时候，在手机司机端上点击“开始工作”,当没有时间或不想做代驾的时候，把手机调为“结束工作”。这就意味着代驾时间由自己决定。接单地点是通过手机GPS定位来实现的，客户能通过客户端选择自己心仪的代驾师傅。</p><p am-list=\"am-list\">3. 派单模式\n（1）客户自助：客人下载爱代驾客户端软件，在手机上就能看到离他最近的一些代驾师傅的信息，选中其中的一位，直接呼叫该代驾师傅来完成代驾服务。\n（2）系统派单：客户下单预约代驾，系统会根据客户预约时间进行派单。</p><p am-list=\"am-list\">4. 假设一位代驾师傅每月有约20个晚上在19：00-23：00接上3单，那么代驾师傅的每月收益约在4000-6000元左右。</p><p am-list=\"am-list\">5. 签约合作需要的物品: \n（1）司机自备安卓系统手机一部用于安装司机端软件。\n手机要求: 安卓手机系统2.3版本以上，最好支持3G或以上网络\n \n（2）代驾必备工具：\n1、入职时不收取购买必备工具的费用\n2、在您离职时如果造成工具遗失需照价赔偿\n3、在职0-3个月内离职的扣除折旧费200元，在职3-12个月内离职的扣除折旧费100元，在职12个月以上离职的不收折旧费。\n夏季服装60元/件；\n冬季服装55/件；\n工牌+工牌挂绳10元/套；\n手套2.5元/副\n服务信息确认单100元/本（离职时归还，丢失者扣除100元）\n座套20元/个\n腰包20元/个\nA6垫板3元/个\nA6写字板2元/个</p><p am-list=\"am-list\">6. 代驾培训新签约合作的代驾师傅在正式接单前由公司统一安排培训，经过培训并考试合格后才能正式进行代驾服务。</p></div></li><li><a am-handle=\"am-handle\">收费标准 &bull; 一线城市</a><div am-content=\"am-content\"><div class=\"price-main\"><div class=\"ptit\"><span" + (jade.attr("am-ico", location, true, false)) + "></span><span>一线城市价格<wbr>（上海・北京・广州・深圳）</span></div><table><tbody><tr><td>时间段</td><td>起步价（10公里内）</td></tr><tr><td>05:00-21:59</td><td>38元</td></tr><tr><td>22:00-22:59</td><td>58元</td></tr><tr><td>23:00-23:59</td><td>78元</td></tr><tr><td>00:00-04:59</td><td>98元</td></tr></tbody></table><div class=\"price-explain\"><div class=\"ptit\">价格说明: </div><div class=\"ptxt\"><span>● </span>不同时段的代驾费计算，以开车起步的起始时间点为准。如21:50开始代驾，22:20结束代驾，起步价即为38元。</div><div class=\"ptxt\"> <span>● </span>每超10公里加收20元，不足10公里按10公里算。</div><div class=\"ptxt\"> <span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div></div></div></div></li><li><a am-handle=\"am-handle\">收费标准 &bull; 二线城市</a><div am-content=\"am-content\"><div class=\"price-main\">\n  <div class=\"ptit\"><span am-ico=\"location\"></span>二线城市A价格<wbr>（南京・常州・无锡・苏州・杭州・宁波・厦门・福州・合肥・天津）</div>\n    <table>\n        <tbody><tr>\n            <td>时间段</td>\n            <td>起步价（10公里内）</td>\n        </tr>\n        <tr>\n            <td>05:00-21:59</td>\n            <td>38元</td>\n        </tr>\n        <tr>\n            <td>22:00-04:59</td>\n            <td>58元</td>\n        </tr>\n    </tbody></table>\n    <div class=\"price-explain\">\n        <div class=\"ptit\">价格说明: </div>\n        <div class=\"ptxt\"><span>● </span>不同时段的代驾费计算，以开车起步的起始时间点为准。如21:50开始代驾，22:20结束代驾，起步价即为38元。</div>\n        <div class=\"ptxt\"><span>● </span>每超5公里加收20元，不足5公里按5公里算。</div>\n        <div class=\"ptxt\"><span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div>\n    </div>\n    <div class=\"ptit\"><span am-ico=\"location\"></span>二线城市B价格<wbr>（大连・石家庄・南昌・郑州・徐州・汕头・武汉・烟台・佛山・湘潭・株洲・长沙・长春・贵阳）</div>\n    <table>\n        <tbody><tr>\n            <td>时间段</td>\n            <td>起步价（10公里内）</td>\n        </tr>\n        <tr>\n            <td>07:00-21:59</td>\n            <td>38元</td>\n        </tr>\n        <tr>\n            <td>22:00-06:59</td>\n            <td>58元</td>\n        </tr>\n    </tbody></table>\n    <div class=\"price-explain\">\n        <div class=\"ptit\">价格说明: </div>\n        <div class=\"ptxt\"><span>● </span>不同时段的代驾费计算，以开车起步的起始时间点为准。如21:50开始代驾，22:20结束代驾，起步价即为38元。</div>\n        <div class=\"ptxt\"><span>● </span>每超5公里加收20元，不足5公里按5公里算。</div>\n        <div class=\"ptxt\"><span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div>\n    </div>\n\n    <div class=\"ptit\"><span am-ico=\"location\"></span>二线城市C价格<wbr>（重庆）</div>\n    <div class=\"price-panel\">\n        全天(10公里起步价）：<span class=\"price\">38</span> 元\n    </div>\n    <div class=\"price-explain\">\n        <div class=\"ptit\">价格说明: </div>\n        <div class=\"ptxt\"><span>● </span>每超5公里加收20元，不足5公里按5公里算。</div>\n        <div class=\"ptxt\"><span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div>\n    </div>\n\n    <div class=\"ptit\"><span am-ico=\"location\"></span>二线城市D价格<wbr>（温州）</div>\n    <table>\n        <tbody><tr>\n            <td>时间段</td>\n            <td>起步价（10公里内）</td>\n        </tr>\n        <tr>\n            <td>07:00-20:59</td>\n            <td>18元</td>\n        </tr>\n        <tr>\n            <td>21:00-06:59</td>\n            <td>28元</td>\n        </tr>\n    </tbody></table>\n    <div class=\"price-explain\">\n        <div class=\"ptit\">价格说明: </div>\n        <div class=\"ptxt\"><span>● </span>不同时段的代驾费计算，以开车起步的起始时间点为准。如20:50开始代驾，21:00结束代驾，起步价即为18元。</div>\n        <div class=\"ptxt\"><span>● </span>每超5公里加收20元，不足5公里按5公里算。</div>\n        <div class=\"ptxt\"><span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div>\n    </div>\n\n    <div class=\"ptit\"><span am-ico=\"location\"></span>二线城市E价格<wbr>（南阳・扬州・洛阳）</div>\n      <table>\n          <tbody><tr>\n              <td>时间段</td>\n              <td>起步价（5公里内）</td>\n          </tr>\n          <tr>\n              <td>07:00-20:59</td>\n              <td>18元</td>\n          </tr>\n          <tr>\n              <td>21:00-06:59</td>\n              <td>28元</td>\n          </tr>\n      </tbody></table>\n      <div class=\"price-explain\">\n          <div class=\"ptit\">价格说明: </div>\n          <div class=\"ptxt\"><span>● </span>每超5公里加收20元，不足5公里按5公里算。</div>\n          <div class=\"ptxt\"><span>● </span>30分钟免费等待，超出部分每30分钟加收20元，不足30分钟按30分钟计算。</div>\n      </div>\n    \n    </div></div></li><li><a am-handle=\"am-handle\">服务规范</a><div am-content=\"am-content\"><p class=\"txt\">为了规范代驾服务，建立公正、公平、公开、透明的环境，代驾员必须坚决履行实施爱代驾统一标准的服务规范。</p><p><div class=\"subtit1\">一、上线准备</div><div><div class=\"subtit2\">1.着装准备</div>工服、工牌、手套、腰包、深色长裤、满口鞋</div><div><div class=\"subtit2\">2. 代驾物品</div>工作手机、服务信息确认单、定额发票、备用零钱、名片、车座椅套、笔、塑料袋、手电筒、垫板和夹板</div></p><p><div class=\"subtit1\">二、接单沟通</div><div><div class=\"subtit2\">1.开始上班</div>登录司机端，输入工号和密码，点击开始上班。工号：如SH0001；密码：默认身份证后6位。</div><div><div class=\"subtit2\">2.等待接单</div>点击“开始上班”后可以看到自己身边的代驾司机，这样您就可以根据具体情况，选择一个适当的位置等待接单。</div><div><div class=\"subtit2\">3. 接收订单</div>如果新订单产生，手机会自动语音播报地址，并以震动响铃的方式提醒司机。有30秒接单时间，如果未点击“接单”，订单则会跳到下一个司机的手机上。</div><div><div class=\"subtit2\">4.电话沟通</div>接单后1分钟内需给客户回电，之后尽快赶到出起始地点，再次与客户电话确认，最后点击“我已到达出发地点”。</div><div><div class=\"subtit2\">5.到达起始地点</div>如已到客户指定地点，点击司机端“我已到达”按钮。</div><div><div class=\"subtit2\">6.再次沟通</div>再次与客户致电，告知我已到达指定地点，询问是否需要继续等待，如需等待告知等待费用计算。等候费收费标准：从预约时间算起，前30分钟免费等待，后每超30分钟加收20元，不足30分钟按30分钟计算。如已到客户预约时间，点击司机端“等候计时”开始计算等候费。</div></p><p><div class=\"subtit1\">三、开始代驾</div><div><div class=\"subtit2\">1.见面沟通</div>先确认客户，再自报身份。与客户核对信息，以免接错客户。沟通时使用敬语，自报工号，并展示工牌，工服，语气温和，态度热情。</div><div><div class=\"subtit2\">2.开关车门</div>先确认客户车辆，双手接过客户钥匙，然后检查车况。</div><div><div class=\"subtit2\">3.铺车座椅套</div>公司规定代驾服务开始之前司机需要帮客户铺设车座椅套，以免弄脏客户车辆。</div><div><div class=\"subtit2\">4.签署服务信息确认单</div>开车之前与客户核对起始公里数，车辆保险、车况等信息，最后开车前务必请客户签字确认。</div><div><div class=\"subtit2\">5.系安全带</div>开车起步不仅自己系好安全带，也要提醒客户系好安全带。</div><div><div class=\"subtit2\">6.开车起步</div>打开司机端，点击“开始代驾”。询问代驾路线，按照客户指定路线开始代驾。</div></p><p><div class=\"subtit1\">四、代驾结束</div><div class=\"txt\">安全平稳停车，关闭所有车窗（天窗），用电设备，检查车辆档位，正确关闭发动机。查看客户里程表，主动与客户核对结束公里数，并填写在服务信息确认单上，告知客户本次代驾总费用（起步价、里程费、等候费）。</div><div><div class=\"subtit2\">1.结账</div>代驾结束后，将服务信息确认单红联、发票、名片、零钱一并交给客户。</div><div><div class=\"subtit2\">2.检查随身物品</div>司机需要检查自己随身物品，不要落在客人车上，以免引起日后不必要的麻烦。</div><div><div class=\"subtit2\">3.开车门</div>下车时同样也要为客户开车门。</div><div><div class=\"subtit2\">4.确认车内物品</div>代驾结束时一定要请客人确认车内物品，以免引起日后不必要的麻烦。</div><div><div class=\"subtit2\">5.归还钥匙</div>双手抵上钥匙，身体向前微倾15°，做鞠躬状。 </div><div><div class=\"subtit2\">6.邀请评价</div>评价率和好评率是之后司机评选活动当中最为重要的参考依据。</div></p></div></li><li><a am-handle=\"am-handle\">交通事故及维修基金</a><div am-content=\"am-content\"><p class=\"txt\">乙方（代驾员）在为客户服务过程中出现的交通事故处理办法：</p><p am-list=\"am-list\">1. 第一时间报警并保留事故责任认定书。</p><p am-list=\"am-list\">2. 如有人员受伤，乙方（代驾员）需拨打交通报警电话，急救电话并将其送往医院，以便得到及时救治。</p><p am-list=\"am-list\">3. 乙方（代驾员）需致电4008 333 199 呼叫中心，报备事情经过及相关信息。</p><p am-list=\"am-list\">4. 乙方（代驾员）免当次代驾费用。</p><p am-list=\"am-list\">5. 一个工作日内协助车主进行定损和维修。</p><p am-list=\"am-list\">6. 保留事故责任认定书、定损单、维修发票、保费总金额复印件、银行卡，快递至公司,上海总部进行付款。</p></div></li><li><a am-handle=\"am-handle\">司机端操作流程</a><div am-content=\"am-content\"><p class=\"tit\">司机端-操作流程（司机互动实操演练）</p><p>司机端下载地址</p><p><a href=\"http://wap.aidaijia.com/dl-drivers.html\" target=\"_blank\">wap.aidaijia.com/dl-drivers.html</a></p><p>正式入职以后，系统即会以短信形式发送您的工号和密码到您的手机，登陆后就可接单赚钱啦</p></div></li></ul><div class=\"wrap1\"><a am-btn=\"bigger block full\" href=\"#examEntrance\">去考试</a></div>");}.call(this,"location" in locals_for_with?locals_for_with.location:typeof location!=="undefined"?location:undefined,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};

this["JST"]["unpass"] = function template(locals) {
var buf = [];
var jade_mixins = {};
var jade_interp;
;var locals_for_with = (locals || {});(function (title) {
buf.push("<header am-row=\"am-row\" class=\"top\"><div am-col=\"1/3\"><a href=\"javascript:history.go(-1)\"><img src=\"images/ico-arrow-left.png\"/></a></div><div am-col=\"1/3\">" + (jade.escape((jade_interp = title) == null ? '' : jade_interp)) + "</div><div am-col=\"1/3\"><span></span></div></header><img src=\"images/unpass.png\" class=\"examed-img\"/><div class=\"examed-info\">很遗憾，您的分数为<span style='color:#e8505b'>58</span>分，请继 续努力！</div><div class=\"wrap1\"><a am-btn=\"bigger block full\" href=\"#train\">在线培训</a></div><div class=\"wrap1\"><a am-btn=\"bigger block full\" href=\"#home\">去主页</a></div>");}.call(this,"title" in locals_for_with?locals_for_with.title:typeof title!=="undefined"?title:undefined));;return buf.join("");
};