(function() {
  jQuery.noConflict();

  window.app = {
    baseUrl: 'http://172.18.2.103:1000',
    Models: {},
    Collections: {},
    Views: {},
    ViewInstances: {},
    Routers: {},
    Data: {},
    init: function() {
      'use strict';
      app.router = new app.Routers;
      Backbone.history.start();
      return FastClick.attach(document.body);
    }
  };

  $(document).ready(function() {
    'use strict';
    return app.init();
  });

}).call(this);

(function() {
  app.Models.areas = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/common/GetAreasByCityId'
  });

}).call(this);

(function() {
  app.Models.channels = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/common/GetSourceType?isNoAll=' + Math.random()
  });

}).call(this);

(function() {
  app.Models.cities = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/common/GetCityByProId'
  });

}).call(this);

(function() {
  app.Models.drivertypes = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/common/CarType?isNoAll=' + Math.random()
  });

}).call(this);

(function() {
  app.Models.provinces = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/common/GetProvince'
  });

}).call(this);

(function() {
  app.Models.questions = Backbone.Model.extend({
    urlRoot: app.baseUrl + '/api/question/GetQuestion'
  });

}).call(this);

(function() {
  app.Models.reg = Backbone.Model.extend({
    rules: {
      fristGainCardTime: {
        require: {
          msg: '请输入初次领证时间'
        },
        func: {
          refer: function(val) {
            var now, threeYearsAgo;
            now = new Date;
            threeYearsAgo = new Date(now.getFullYear() - 3, now.getMonth(), now.getDate());
            return (new Date(val.slice(0, 4), (val.slice(5, 7)) - 1, val.slice(8))) > threeYearsAgo;
          },
          msg: '驾龄不能小于三年'
        }
      },
      driverName: {
        require: {
          msg: '请输入姓名'
        },
        minLength: {
          refer: 2,
          msg: '姓名不能少于两个字'
        },
        maxLength: {
          refer: 8,
          msg: '姓名不能多于八个字'
        },
        regular: {
          refer: /[\u4E00-\u9FA5]/,
          msg: '姓名必须是中文'
        }
      },
      phone: {
        require: {
          msg: '请输入手机号码'
        },
        regular: {
          refer: /^1\d{10}$/,
          msg: '请输入正确的手机号'
        }
      },
      verifyCode: {
        require: {
          msg: '验证码错误，请输入正确的验证码'
        },
        minLength: {
          refer: 6,
          msg: '验证码必须是6位数字'
        },
        maxLength: {
          refer: 6,
          msg: '验证码必须是6位数字'
        }
      },
      provinceId: {
        require: {
          msg: '请输入工作省'
        }
      },
      cityId: {
        require: {
          msg: '请输入工作市'
        }
      },
      districtId: {
        require: {
          msg: '请输入工作区/县'
        }
      },
      sourceType: {
        require: {
          msg: '请选择渠道来源'
        }
      },
      nric: {
        require: {
          msg: '请输入身份证号码'
        },
        regular: {
          refer: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
          msg: '请输入正确的身份证号码'
        },
        func: {
          refer: function(val) {
            var fiftyFiveYearsAgo, now;
            now = new Date;
            fiftyFiveYearsAgo = new Date(now.getFullYear() - 55, now.getMonth(), now.getDate());
            return (new Date(val.slice(6, 10), val.slice(10, 12), val.slice(12, 14))) < fiftyFiveYearsAgo;
          },
          msg: '对不起，55岁以下才能报名'
        }
      },
      licenseType: {
        require: {
          msg: '请选择驾照类型'
        }
      }
    },
    funcs: {
      require: function(val) {
        return val === null || val === '' || val === void 0;
      },
      minLength: function(val, refer) {
        return $.trim(val).length < refer;
      },
      maxLength: function(val, refer) {
        return $.trim(val).length > refer;
      },
      regular: function(val, refer) {
        return !refer.exec($.trim(val));
      },
      func: function(val, refer) {
        return refer(val);
      }
    },
    validate: function(attrs, opts) {
      var errnum, k, k1, k2, ref, ref1, t, v, v1, v2;
      errnum = 0;
      if (opts.target) {
        t = opts.target;
        ref = this.rules[t];
        for (k in ref) {
          v = ref[k];
          if (this.funcs[k](attrs[t], v.refer)) {
            return {
              target: t,
              msg: v.msg
            };
          } else {
            this.trigger('valid', this, t);
          }
        }
      } else {
        ref1 = this.rules;
        for (k1 in ref1) {
          v1 = ref1[k1];
          for (k2 in v1) {
            v2 = v1[k2];
            if (this.funcs[k2](attrs[k1], v2.refer)) {
              this.trigger('invalid', this, {
                target: k1,
                msg: v2.msg
              });
              errnum++;
              break;
            }
          }
        }
        if (errnum > 0) {
          return 'error';
        } else {
          return void 0;
        }
      }
    }
  });

}).call(this);

(function() {
  app.Routers = Backbone.Router.extend({
    container: $('#views'),
    shiftView: function(newView) {
      if (this.view) {
        this.view.remove();
      }
      return this.view = newView;
    },
    routes: {
      '': "home",
      'login': 'login',
      'reg': 'reg',
      'train': 'train',
      'notice': 'notice',
      'progress': 'progress',
      'examEntrance': 'examEntrance',
      'exam/:num': 'exam',
      'pass': 'pass',
      'unpass': 'unpass',
      '*action': 'home'
    },
    home: function() {
      var home;
      home = new app.Views.home;
      this.shiftView(home);
      return this.container.append(home.render().$el);
    },
    login: function() {
      var login;
      login = new app.Views.login;
      this.shiftView(login);
      return this.container.append(login.render().$el);
    },
    reg: function() {
      var reg;
      reg = new app.Views.reg;
      this.shiftView(reg);
      return this.container.append(reg.render().$el);
    },
    train: function() {
      var train;
      train = new app.Views.train;
      this.shiftView(train);
      return this.container.append(train.render().$el);
    },
    notice: function() {
      var notice;
      notice = new app.Views.notice;
      this.shiftView(notice);
      return this.container.append(notice.render().$el);
    },
    progress: function() {
      var progress;
      if (!($.fn.cookie('uid'))) {
        this.navigate('login', {
          trigger: true,
          replace: true
        });
        return;
      }
      progress = new app.Views.progress;
      this.shiftView(progress);
      return this.container.append(progress.render().$el);
    },
    examEntrance: function() {
      var examEntrance;
      examEntrance = new app.Views.examEntrance;
      this.shiftView(examEntrance);
      return this.container.append(examEntrance.render().$el);
    },
    exam: function(num) {
      var exam;
      if (!($.fn.cookie('uid'))) {
        this.navigate('login', {
          trigger: true,
          replace: true
        });
        return;
      }
      if (num < 1) {
        this.navigate('examEntrance', {
          trigger: true,
          replace: true
        });
        return;
      }
      exam = new app.Views.exam({
        num: num
      });
      return this.shiftView(exam);
    },
    pass: function() {
      var pass;
      if (!($.fn.cookie('uid'))) {
        this.navigate('login', {
          trigger: true,
          replace: true
        });
        return;
      }
      pass = new app.Views.pass;
      this.shiftView(pass);
      return this.container.append(pass.render().$el);
    },
    unpass: function() {
      var unpass;
      if (!($.fn.cookie('uid'))) {
        this.navigate('login', {
          trigger: true,
          replace: true
        });
        return;
      }
      unpass = new app.Views.unpass;
      this.shiftView(unpass);
      return this.container.append(unpass.render().$el);
    }
  });

}).call(this);

(function() {
  app.Views.exam = Backbone.View.extend({
    answer: {},
    initdata: {
      title: '在线考试',
      finalOne: false
    },
    initialize: function(opts) {
      this.initdata.num = Number(opts.num);
      if (app._res) {
        return $('#views').append(this.render(app._res).$el);
      } else {
        return (new app.Models.questions).fetch({
          success: (function(_this) {
            return function(model, res) {
              app._res = res;
              return $('#views').append(_this.render(res).$el);
            };
          })(this)
        });
      }
    },
    template: JST['exam'],
    render: function(data) {
      this.initdata.count = data.count;
      this.answer.index = this.initdata.num = this.initdata.num <= this.initdata.count ? this.initdata.num : this.initdata.count;
      if (this.initdata.num === this.initdata.count) {
        this.initdata.finalOne = true;
      } else {
        this.initdata.finalOne = false;
      }
      this.initdata.question = data.data[this.initdata.num - 1];
      this.$el.html(this.template(this.initdata));
      return this;
    },
    events: {
      'change .options input': '_change',
      'click #nextQ': '_next',
      'click #submit': '_submit'
    },
    _change: function() {
      this.$('#nextQ,#submit').show();
      return this.answer.item = this.$('input[type=radio]:checked').val();
    },
    _next: function() {
      var answers;
      answers = (JSON.parse($.fn.cookie('answers'))) || [];
      answers.splice(this.answer.index - 1, 1, this.answer);
      return $.fn.cookie('answers', JSON.stringify(answers));
    },
    _submit: function() {
      var answers;
      answers = (JSON.parse($.fn.cookie('answers'))) || [];
      answers.splice(this.answer.index - 1, 1, this.answer);
      $.fn.cookie('answers', JSON.stringify(answers));
      return $.ajax({
        type: 'POST',
        url: app.baseUrl + '/api/question/SubmitAnswer',
        data: {
          nric: $.fn.cookie('uid'),
          result: $.fn.cookie('answers')
        },
        success: (function(_this) {
          return function(res) {
            if (res.Code === 0) {
              $.fn.cookie('isExarm', true);
              return app.router.navigate('pass', {
                trigger: true
              });
            }
          };
        })(this)
      });
    }
  });

}).call(this);

(function() {
  app.Views.examEntrance = Backbone.View.extend({
    template: JST['examEntrance'],
    render: function() {
      this.$el.html(this.template({
        title: '在线考试',
        isExarm: $.fn.cookie('isExarm')
      }));
      return this;
    }
  });

}).call(this);

(function() {
  app.Views.home = Backbone.View.extend({
    initialize: function() {
      var getSearch, registerSrc;
      getSearch = function(k) {
        var end, start;
        if ((location.search.indexOf(k)) === -1) {
          return '';
        } else {
          start = (location.search.indexOf(k)) + k.length + 1;
          end = (location.search.indexOf('&')) === -1 ? void 0 : location.search.indexOf('&', start);
          return location.search.slice(start, end);
        }
      };
      registerSrc = (getSearch('src')) === 'baidu' ? 1 : 0;
      return $.fn.cookie('registerSrc', registerSrc);
    },
    template: JST['home'],
    render: function() {
      this.$el.html(this.template());
      return this;
    }
  });

}).call(this);

(function() {
  app.Views.login = Backbone.View.extend({
    template: JST['login'],
    render: function() {
      this.$el.html(this.template({
        title: '登录'
      }));
      return this;
    },
    events: {
      'click .btn-login': 'login'
    },
    login: function() {
      var _id;
      _id = this.$el.find('#ID').val();
      if (/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.exec(_id)) {
        return $.ajax({
          type: 'GET',
          url: app.baseUrl + '/api/DriverStatus/SearchProgress',
          data: {
            nric: _id
          },
          success: (function(_this) {
            return function(res) {
              if (res.Code === 0) {
                $.fn.cookie('uid', _id);
                $.fn.cookie('isOnlineTrain', res.Data[0].isOnlineTrain);
                $.fn.cookie('isExarm', res.Data[0].isExarm);
                return app.router.navigate('#progress', {
                  trigger: true
                });
              } else if (res.Code === -1) {
                return _this.$el.find('#ID_err').text('未注册');
              } else {
                return _this.$el.find('#ID_err').text('登陆失败');
              }
            };
          })(this)
        });
      } else {
        return this.$el.find('#ID_err').text('身份证格式错误');
      }
    }
  });

}).call(this);

(function() {
  app.Views.notice = Backbone.View.extend({
    template: JST['notice'],
    render: function() {
      this.$el.html(this.template({
        title: '服务条款'
      }));
      return this;
    }
  });

}).call(this);

(function() {
  app.Views.pass = Backbone.View.extend({
    template: JST['pass'],
    render: function() {
      this.$el.html(this.template({
        title: '在线考试'
      }));
      return this;
    }
  });

}).call(this);

(function() {
  app.Views.progress = Backbone.View.extend({
    template: JST['progress'],
    render: function() {
      var _id;
      this.$el.html(this.template({
        title: '报名进度'
      }));
      _id = String($.fn.cookie('uid')).split('');
      _id.splice(6, 8, '******');
      _id = _id.join('');
      this.$('#uid').text(_id);
      if ($.fn.cookie('isExarm')) {
        this.$('#isExarm').attr('disabled', 'disabled').attr('href', 'javascript:;').text('已完成');
      }
      if ($.fn.cookie('isOnlineTrain')) {
        this.$('#isOnlineTrain').attr('disabled', 'disabled').attr('href', 'javascript:;').text('已完成');
        this.$('.signup-success').css('display', 'block');
      }
      return this;
    }
  });

}).call(this);

(function() {
  app.Views.reg = Backbone.View.extend({
    model: new app.Models.reg,
    initialize: function() {
      (new app.Models.provinces).fetch({
        success: (function(_this) {
          return function(model, res) {
            return _this.addProvinces(res);
          };
        })(this)
      });
      (new app.Models.channels).fetch({
        success: (function(_this) {
          return function(model, res) {
            return _this.addChannels(res);
          };
        })(this)
      });
      (new app.Models.drivertypes).fetch({
        success: (function(_this) {
          return function(model, res) {
            return _this.addDrivertypes(res);
          };
        })(this)
      });
      this.model.on('invalid', (function(_this) {
        return function(model, error) {
          return _this.$el.find('#' + error.target + '_err').text(error.msg);
        };
      })(this));
      this.model.on('valid', (function(_this) {
        return function(model, id) {
          return _this.$el.find('#' + id + '_err').text('');
        };
      })(this));
      jQuery(document).on('focus', '#fristGainCardTime', function() {
        return jQuery(this).date({
          beginyear: 1970,
          curdate: true
        });
      });
      jQuery(document).on('click', '#dateconfirm', function() {
        return $('#fristGainCardTime').change();
      });
      return this.model.set('registerSrc', $.fn.cookie('registerSrc'));
    },
    template: JST['reg'],
    render: function() {
      this.$el.html(this.template({
        title: '司机招聘'
      }));
      return this;
    },
    events: {
      'click .submit': '_submit',
      'touchstart .reg-success': 'stopPop',
      'change #provinceId': 'selectProvince',
      'change #cityId': 'selectCity',
      'change input,select': '_change',
      'click #getverification': 'getverification'
    },
    _change: function(e) {
      this.model.set(e.target.id, e.target.value, {
        target: e.target.id,
        validate: true
      });
      if (e.target.id === 'fristGainCardTime') {
        return this.$('#fristGainCardTime+.placeholder').hide();
      }
    },
    _submit: function() {
      if (this.model.isValid()) {
        return $.ajax({
          type: 'POST',
          url: app.baseUrl + '/api/DriverInfo/InsertDriverInfo',
          data: this.model.toJSON(),
          success: (function(_this) {
            return function(res) {
              if (res.Code === 0) {
                $.fn.cookie('uid', _this.model.get('nric'));
                $.fn.cookie('isExarm', null);
                $.fn.cookie('isOnlineTrain', null);
                return _this.$el.find('.reg-success').show();
              } else {
                return alert(res.ErrMsg);
              }
            };
          })(this)
        });
      }
    },
    stopPop: function(e) {
      return e.preventDefault();
    },
    addProvinces: function(provinces) {
      var htmlAry;
      htmlAry = ['<option>请选择工作省</option>'];
      _.forEach(provinces, function(v, k) {
        return htmlAry.push('<option value="' + v.RegionId + '">' + v.RegionName + '</option>');
      });
      return this.$el.find('#provinceId').html(htmlAry.join(''));
    },
    addChannels: function(channels) {
      var htmlAry;
      htmlAry = ['<option>请选择来源渠道</option>'];
      _.forEach(channels, function(v, k) {
        return htmlAry.push('<option value="' + v.Value + '">' + v.Name + '</option>');
      });
      return this.$el.find('#sourceType').html(htmlAry.join(''));
    },
    addDrivertypes: function(drivertypes) {
      var htmlAry;
      htmlAry = ['<option>请选择驾照类型</option>'];
      _.forEach(drivertypes, function(v, k) {
        return htmlAry.push('<option value="' + v.Value + '">' + v.Name + '</option>');
      });
      return this.$el.find('#licenseType').html(htmlAry.join(''));
    },
    addCities: function(cities) {
      var htmlAry;
      htmlAry = [];
      _.forEach(cities, function(v, k) {
        return htmlAry.push('<option value="' + v.RegionId + '">' + v.RegionName + '</option>');
      });
      return this.$el.find('#cityId').html(htmlAry.join(''));
    },
    addAreas: function(areas) {
      var htmlAry;
      htmlAry = [];
      _.forEach(areas, function(v, k) {
        return htmlAry.push('<option value="' + v.RegionId + '">' + v.RegionName + '</option>');
      });
      return this.$el.find('#districtId').html(htmlAry.join(''));
    },
    selectProvince: function(e) {
      return (new app.Models.cities).fetch({
        data: {
          proId: e.target.value
        },
        success: (function(_this) {
          return function(model, res) {
            _this.addCities(res);
            return _this.$('#cityId').change();
          };
        })(this)
      });
    },
    selectCity: function(e) {
      return (new app.Models.areas).fetch({
        data: {
          cId: e.target.value
        },
        success: (function(_this) {
          return function(model, res) {
            _this.addAreas(res);
            return _this.$('#districtId').change();
          };
        })(this)
      });
    },
    getverification: function() {
      var phone;
      phone = (this.$el.find('#phone')).val();
      if (/^1\d{10}$/.exec(phone)) {
        $('#getverification').attr('disabled', 'disabled');
        return $.ajax({
          type: 'POST',
          url: app.baseUrl + '/api/common/InsertSMS',
          data: {
            phone: phone
          },
          success: (function(_this) {
            return function() {
              var counts;
              counts = 60;
              return setTimeout(function() {
                $('#getverification').text(--counts);
                if (counts > 0) {
                  return setTimeout(arguments.callee, 1000);
                } else {
                  return $('#getverification').text('获取验证码').removeAttr('disabled');
                }
              }, 0);
            };
          })(this)
        });
      } else {
        return this.$('#phone').change();
      }
    }
  });

}).call(this);

(function() {
  app.Views.train = Backbone.View.extend({
    initialize: function() {
      if (!$.fn.cookie('isOnlineTrain')) {
        return $.ajax({
          type: 'POST',
          url: app.baseUrl + '/api/DriverStatus/editIsOnlineTrain',
          data: {
            nric: $.fn.cookie('uid')
          },
          success: function() {
            return $.fn.cookie('isOnlineTrain', true);
          }
        });
      }
    },
    template: JST['train'],
    render: function() {
      this.$el.html(this.template({
        title: '在线培训'
      }));
      return this;
    },
    events: {
      'click [am-accordion] [am-handle]': 'toggle'
    },
    toggle: function(e) {
      if (!$(e.target).hasClass('open')) {
        this.$('.open').removeClass('open');
      }
      return (this.$(e.target)).toggleClass('open');
    }
  });

}).call(this);

(function() {
  app.Views.unpass = Backbone.View.extend({
    template: JST['unpass'],
    render: function() {
      this.$el.html(this.template({
        title: '在线考试'
      }));
      return this;
    }
  });

}).call(this);
